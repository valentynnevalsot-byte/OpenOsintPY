#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  ██████╗  ██████╗ ███╗   ██╗ ██████╗ ██████╗ ███████╗██╗███╗   ██╗████████╗██╗   ██╗
# ██╔═══██╗██╔═══██╗████╗  ██║██╔═══██╗██╔══██╗██╔════╝██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝
# ██║   ██║██║   ██║██╔██╗ ██║██║   ██║██████╔╝███████╗██║██╔██╗ ██║   ██║    ╚████╔╝
# ██║   ██║██║   ██║██║╚██╗██║██║   ██║██╔═══╝ ╚════██║██║██║╚██╗██║   ██║     ╚██╔╝
# ╚██████╔╝╚██████╔╝██║ ╚████║╚██████╔╝██║     ███████║██║██║ ╚████║   ██║      ██║
#  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝      ╚═╝
#                    O p e n O s i n t P Y   v2.0
#                    Created by injectorX69

import os
import sys
import time
import random
import socket
import itertools
import threading
import re
import webbrowser

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

# ------------------------- COLORS -------------------------
class C:
    R   = "\033[91m"
    G   = "\033[92m"
    Y   = "\033[93m"
    B   = "\033[94m"
    M   = "\033[95m"
    C   = "\033[96m"
    W   = "\033[97m"
    GR  = "\033[90m"
    BOLD = "\033[1m"
    DIM  = "\033[2m"
    END  = "\033[0m"

# ------------------------- ASCII BANNER -------------------------
BANNER = r"""
  ██████╗  ██████╗ ███╗   ██╗ ██████╗ ██████╗ ███████╗██╗███╗   ██╗████████╗██╗   ██╗
 ██╔═══██╗██╔═══██╗████╗  ██║██╔═══██╗██╔══██╗██╔════╝██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝
 ██║   ██║██║   ██║██╔██╗ ██║██║   ██║██████╔╝███████╗██║██╔██╗ ██║   ██║    ╚████╔╝
 ██║   ██║██║   ██║██║╚██╗██║██║   ██║██╔═══╝ ╚════██║██║██║╚██╗██║   ██║     ╚██╔╝
 ╚██████╔╝╚██████╔╝██║ ╚████║╚██████╔╝██║     ███████║██║██║ ╚████║   ██║      ██║
  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝      ╚═╝
                Created by injectorX69  |  OSINT & Cyber Toolkit
"""

ART = r"""
@M@M@M@M@M@M@MM@M@@@M@M@M@M@M@M@@@MMMM@M@@@M@M@@@M@M@M@@@M@MM@M@@MMMM@adJcjJOJccaMMM@M@M@M@M@M@M
@M@@@M@M@@@M@M@@M@@@@@M@M@@@@@M@M@@@@@MM@@@@@M@M@@@@@M@M@@@M@MOJ{|jJjaJaJc|{I-j-I-|ja@@M@@@M@M@@@@@M
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@aOJO>I-c{aOMddda{JJcjO--a@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@MMaMMMMaM@Mdcc>|OjOJ>j@M@M@@@@@M@M@MMMO-JacJJOOMOaOddaOaddddcJda@@@@@@@M@@@@@@
@MMM@M@M@M@M@M@MM@MOdMdO>{>-O-jada-jc|->ad--cdMOddMaMdaOd|>I-OOaOddddaOaddOaJacJjJ>d-cdM@M@M@M@M@M@M
@M@M@M@M@M@M@M@@MMdI{OOMOcOJOaOaaadadaadMdaJ-ja>{>ccddMdOOd-|aaO-j||Jc>JccJd{O-j-{-OJ-{d@M@M@M@M@M@M
@@@@@@@@@@@@@@Md|cc|JddMdaaadMdaaadadaadMdddddaJc-JOMOO|J-a>djcj{>--|j-c-|cJ-d|Jj-jj{{{-d@@@@M@@@@@M
@@@@@M@@@@@@@@@d->|ddaOMOaddOMOaddddOdddOOJj-J|"cjc-a>J-O{>|jjcc||jcjO|OjjcJjdjccj>djJc>IO@@@@@@@@@@
@M@@@@@M@@@M@M@d-cOOOdcaJOJOja|dj-d">Jjcjd-JjJJ>JIccOjdjc|jjJJcc|jjccd|M->jdJM@MMMM>ccj>O{aMMM@M@M@M
@M@M@M@M@M@M@MMd-JdOJJ>jO||c-a{Jj{jc>|OcJjjcJcajcjc|jcOjJdOJdd|{>da@M@M@aOa@M@dOaMJcc|{jMdO|{JaM@M@M
@M@M@M@M@M@M@@@d-cO|cc-ac||J-ajOccjcjJJcc--|ddMOJaaj{aMM@@@M@MM@M@@@M@Md|>|j{M|jdO|{JOaOadada-JM@M@M
@M@M@M@M@M@M@M@O-cJ|cJjdcJjcjdc{-JdMaMadOjcOMM@M@@@M@M@M@@@M@MM@M@MMM@MO{|{j"J-ddddaOOOJ{OadaJO{aM@M
@@@@@@@M@@@@@@MO-d>jcc-c|aM@M@MadM@@M@@M@@@@MM@M@@@OadaM@@@MM@M@@@d{|{OdJdOa"J-JdOJdOddcOJdOdjc-d@@M
@M@M@M@M@M@M@M@d-d>j{JM@M@@@M@M@MMaMaaaOMMMd|I||djj->cOJadOcccjOcOOa|Jcd{JdaOMdaaadaJOdcdOJJdO--dM@M
@M@M@M@M@M@M@MMd-cOj{cM@adOOOd@@d{--I---OJdI-IaJaOdOMJadMjdcdc|-cOJOJajacOJdcaJOJJJOJOdcMdcjd||>dM@M
@MMM@M@MMMMM@MMO-jccj|d@ac||{||MMaMM{aaOadadadMdMdadMdMdajdcaaJdcOOOJacaJOJdcaJOJOJdJOdcdOJca>-|dMMM
@MMM@M@MMM@M@MMd---cOJa@dj-{-{>|{{-{cJddaOddadMOaOdOMOMdddOcdOOdcOOOJacaJOOacaJOOdJdOOOJM{Odd>>-MM@M
@@@@@M@M@@@@@@@d-->jcJM@MaadddjJOJ->JdddaOdddOMJaOdOaJaOdJccaOOaJOOOOajaJOJdOaJJccJOdddJaJddd-|c@M@M
@MMM@M@MMMMM@MMMJ|-jcJa@a|>>>-IjOM-@JdOJ|dOJdJMcaJOJacaJOJc{dJJOjJJOJd"c{ccMcaJOOOOOOOdcdJOOd-jO@MMM
MMMMMa@aMMMM@aMd-{>cOcd@adJJcJ{ddMMMdaaJc|aaadMdMdadMdMdaaM>aOaJ-jOadMdMdadadMdaaadaaaadaaaaa>jMMMMa
@MMM@M@MMMMM@MMO||>c||d@acjj|jJadaaadaaOc{aaaaMdMdadMdMaaaadMaaMdaaaaMdMdaaadMaaaaaaaaadaaaaa>jMMMMM
@MMM@M@M@M@M@M@MO|>j{cM@M@@@OMJdOOdadaaaMdaaadMdMdadMdMdadadaaaadaaadMdMdadadMdaaaaaaaadadada>jM@M@M
@M@M@M@M@M@M@MMMd|-J|JM@a|>>>{ddjOddOddOaOOOdOMJaOdOaJaOdOdOadOaOdOdOaJaOdOaJaOddOOddddOaOdjJ>jM@MMM
MaMMMa@aMaMa@aMMa|>j|OaMaMaMcccdJJdadaaaadaaadMdMdadMdMdaaadaaaadaaadMdMdadadMdaaaaaaaadadaa|IjaMMMa
MaMa@a@aMaMa@aMMM|>cjJaMaMOj>OJMJcdMaMMaMaaaMa@aMaMaMaMaMaMaMMaMaMaMaMaMaMaMaMaMaaaMaMMaMaMJ|IjaMaMa
@MMM@M@MMMMM@MMMM|>cJOa@aj>I>aJMJJaMaMMaMaMaMaMaMaMaMaMaMaMaMMaMaMaMaMaMaMaMaMaMMMaMMaMaMaMc>>cM@MMM
@M@M@M@M@M@M@M@MM|>jcOM@aj>>|McaaadadaaaMdadadMdMdadMdMdaaadaaaadaaadMdMdadadMdaaadaaaadadac>jjM@M@M
@MMM@M@MMMMM@MMMM|I-JOa@ajI>jMcMaaaadaaaMdaaaaMdMdadMdMaaaadMaaMdaaaaMdMdaaadMaaaaaaaaadMaac>>MMMMMM
MaMMMa@aMMMa@aMMa|I>|JaMd{>>jMcJcaaMaMMaMaaaMaMaMaMaMaMaMaMaMaaMaMaMaMaMaMaMaMaMaaaMaMMaMaMc>d@aMMMa
@MMM@a@MMMMM@MMMM|I{jJa@ad{IjMJccMMMMMMMMMMMMM@MMMMMMM@MMMMMMMMMMMMMM@MMMMMMM@MMMMMMMMMMMMMc>a@MMMMM
@MMM@M@MMM@M@MMMM|>ccOM@aMjIjMOdOMaMaMMaMaMMMaMaMaMaMaMaMaMaMMMMaMMMaMaMaMaMaMaMMMaMMMMaMaaj>a@M@MMM
@MMM@M@MMMMM@MMMM|I>{Oa@MMc>jMOdcaaMaaaaMaaaaaMdMaaaMdMaaaaaMaaMaaaaaMdMaaaMdMaaaaaaaaMaMdJj-d@MMMMM
@MMM@M@MMMMM@MMMM|II{Oa@aMc>jMddOaaMaMaaMaaaMaMdMaaaMdMaaaaaMaaMaaaaaMdMaaaMaMaaaaaMaaMdMOjj>d@MMMMM
MMMM@M@MMMMM@MMMM|>I{Oa@aad{jMdMMMaMaMMMMaMMMa@aMaMaMaMMMMMaMMMMaMMMMMaMaMMMaMMMMMaMMMMddJ|>-d@MMMMM
@MMM@M@MMMMM@MMMM|cI-da@a||OJMdMMMMMMMMMMMMMMM@MMMMM@M@MMMMMMMMMMMMMM@M@MMMMMMd{{{{{{{{{{>IIca@M@MMM
@MMM@M@M@M@M@MMMMJdI{c|Md{{OcdIMMMaMaMMMMaMMMa@aMaMaMaMMMMMaMMaMaaaaaa"Oc{---{->I"IIII-{j|jOMM@M@MMM
@MMM@M@MMM@M@M@MM@aI-c>->{|Oca|daaaMaaaaMaaaaaMdMaadMOaOOOOOOJJj>>I>>{I{>II>I-jJJJOJJOdM@MMM@M@M@MMM
@MMM@M@MMMMM@MMMMMaII|{dO{|dOcJdaaaaaMaaMadddJOjOcc|c||>>II>>->{I>I>|ddadadadaM@@MMMMM@M@MMM@M@M@MMM
@MMM@M@MMM@M@MMMMMa>>I>cjOJOa-aMadOO|jj|c||{{I-I->>>->{-->>OdaaMMMMMM@a@M@MMa@MM@MMMMMMM@MMMMM@MMMMM
@MMM@M@MMMMM@MMMM@MMJ-I>>{>->I-{{->>""I>|>----|-Oa@M@a@M@@@MMMM@M@MMM@a@M@M@a@MM@MMMMM@M@MMM@M@M@MMM
@M@M@M@M@@@M@M@@M@@@@Mcc--IIII>cccjcjcca@@@@@M@M@@@M@M@M@@@M@MM@M@@@M@M@@@M@M@M@@@@@M@@M@M@M@M@M@M@M
@M@M@M@M@M@M@M@MM@@@@@MMadOOOOdMM@@@M@MM@M@@@M@M@@@M@M@M@@@M@MM@M@@MM@M@M@@@M@M@@@M@MM@M@M@M@M@M@@@M
"""

# ------------------------- HELPERS -------------------------
def clear():
    os.system("cls" if os.name == "nt" else "clear")

def slow_print(text, delay=0.008, color=""):
    print(color + text + C.END, end="", flush=True)

def banner():
    clear()
    # banner line by line, like a boot sequence
    colors = [C.R, C.M, C.C, C.G]
    for i, line in enumerate(BANNER.splitlines()):
        print(colors[i % len(colors)] + C.BOLD + line + C.END)
        time.sleep(0.04)
    for line in ART.splitlines():
        print(C.DIM + C.M + line + C.END)
        time.sleep(0.012)
    print()
    print(C.GR + "  " + "─" * 68 + C.END)

def spinner(text, duration=1.2):
    """Rotating spinner with text."""
    frames = itertools.cycle(["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"])
    end_time = time.time() + duration
    while time.time() < end_time:
        sys.stdout.write("\r  " + C.C + next(frames) + C.END + " " + text + "   ")
        sys.stdout.flush()
        time.sleep(0.07)
    sys.stdout.write("\r  " + C.G + "✔" + C.END + " " + text + C.G + "  done!" + C.END + "\n")
    sys.stdout.flush()

def progress_bar(text, duration=1.0, width=40):
    """Animated progress bar."""
    steps = 30
    for i in range(steps + 1):
        pct = int(i / steps * 100)
        filled = int(i / steps * width)
        bar = C.G + "█" * filled + C.GR + "░" * (width - filled) + C.END
        sys.stdout.write(f"\r  {C.Y}{text}{C.END} {bar} {C.B}{pct:3d}%{C.END}")
        sys.stdout.flush()
        time.sleep(duration / steps)
    print(C.G + "  ✔" + C.END)

def boot_sequence():
    """Startup: banner + fake module loading + big progress bar."""
    banner()
    mods = [
        "Loading core modules",
        "Loading OSINT engines",
        "Loading network scanner",
        "Loading P.Y.AI brain",
        "Checking dependencies",
    ]
    for m in mods:
        spinner(m, random.uniform(0.4, 0.9))
    time.sleep(0.2)
    progress_bar("Starting OpenOsintPY", 1.2)
    print()
    print(C.G + C.BOLD + "  ✔ OpenOsintPY is ready!" + C.END)
    print(C.GR + "  " + "─" * 68 + C.END)
    print(C.M + C.BOLD + "        ★ Created by injectorX69 ★" + C.END)
    time.sleep(1.2)

def pause():
    input(C.Y + "\n  [*] Press ENTER to return to menu..." + C.END)

# ------------------------- MODULES -------------------------
def name_tracer():
    banner()
    spinner("Initializing name tracer", 0.6)
    slow_print("  [1] NAME TRACER\n")
    name = input(C.G + "  [?] Enter full name: " + C.END)
    if name:
        spinner("Searching public sources", 0.8)
        query = name.replace(" ", "+")
        links = [
            f"https://www.google.com/search?q=%22{name}%22",
            f"https://www.linkedin.com/search/results/people/?keywords={query}",
            f"https://github.com/search?q={query}&type=users",
            f"https://www.youtube.com/results?search_query={query}",
        ]
        print(C.G + "  [+] Results found:" + C.END)
        for l in links:
            print(C.Y + "    [>] " + l + C.END)
        if input(C.G + "  [?] Open in browser? (y/n): " + C.END).lower() == "y":
            for l in links:
                webbrowser.open(l)
    pause()

def phone_tracer():
    banner()
    spinner("Initializing phone tracer", 0.6)
    slow_print("  [2] PHONE NUMBER TRACER\n")
    phone = input(C.G + "  [?] Enter phone number (e.g. +420...): " + C.END).strip()
    digits = re.sub(r"\D", "", phone)
    if digits:
        spinner("Analyzing number +" + digits, 1.0)
        try:
            import phonenumbers
            from phonenumbers import geocoder, carrier, timezone
            p = phonenumbers.parse("+" + digits)
            if phonenumbers.is_valid_number(p):
                print(C.G + f"  [+] Valid      : Yes")
                print(C.G + f"  [+] Country    : {geocoder.country_name_for_number(p, 'en')}")
                print(C.G + f"  [+] Region     : {geocoder.description_for_number(p, 'en')}")
                print(C.G + f"  [+] Carrier    : {carrier.name_for_number(p, 'en')}")
                print(C.G + f"  [+] Timezone(s): {', '.join(timezone.time_zones_for_number(p))}")
            else:
                print(C.R + "  [-] Invalid number." + C.END)
        except ImportError:
            print(C.Y + "  [!] Install: pip install phonenumbers" + C.END)
    pause()

def ip_lookup():
    banner()
    spinner("Initializing IP lookup", 0.6)
    slow_print("  [3] IP LOOKUP\n")
    ip = input(C.G + "  [?] Enter IP or domain: " + C.END).strip()
    try:
        target_ip = socket.gethostbyname(ip)
        print(C.G + f"  [+] Resolved IP : {target_ip}" + C.END)
    except socket.gaierror:
        print(C.R + "  [-] Could not resolve host." + C.END)
        target_ip = ip
    spinner("Querying geolocation database", 1.0)
    if HAS_REQUESTS:
        try:
            r = requests.get(f"http://ip-api.com/json/{target_ip}", timeout=10).json()
            for k, label in [("country","Country"),("city","City"),("isp","ISP"),
                             ("org","Org"),("as","AS"),("lat","Latitude"),("lon","Longitude")]:
                print(C.G + f"  [+] {label:<11}: {r.get(k)}" + C.END)
        except Exception as e:
            print(C.R + f"  [-] Lookup failed: {e}" + C.END)
    else:
        print(C.Y + "  [!] Install: pip install requests" + C.END)
    pause()

def whatsapp_tracer():
    banner()
    spinner("Initializing WhatsApp tracer", 0.6)
    slow_print("  [4] WHATSAPP TRACER\n")
    phone = input(C.G + "  [?] Enter number (with country code): " + C.END).strip()
    url = f"https://wa.me/{re.sub(r'[^0-9]', '', phone)}"
    print(C.Y + f"  [>] Check link: {url}" + C.END)
    if input(C.G + "  [?] Open in browser? (y/n): " + C.END).lower() == "y":
        webbrowser.open(url)
    pause()

def tiktok_lookup():
    banner()
    spinner("Initializing TikTok lookup", 0.6)
    slow_print("  [5] TIKTOK LOOKUP\n")
    user = input(C.G + "  [?] Enter username: " + C.END).strip().lstrip("@")
    if user:
        spinner("Scanning platforms", 1.0)
        urls = [
            f"https://www.tiktok.com/@{user}",
            f"https://www.youtube.com/@{user}",
            f"https://instagram.com/{user}",
            f"https://github.com/{user}",
            f"https://twitter.com/{user}",
        ]
        for u in urls:
            print(C.Y + "    [>] " + u + C.END)
        if input(C.G + "  [?] Open in browser? (y/n): " + C.END).lower() == "y":
            for u in urls:
                webbrowser.open(u)
    pause()

def cmd_graph():
    banner()
    spinner("Initializing graph engine", 0.6)
    slow_print("  [6] CMD GRAPH\n")
    data = input(C.G + "  [?] Enter numbers separated by space:\n  > " + C.END).split()
    try:
        vals = [float(x) for x in data]
        maxv = max(vals) if vals else 1
        spinner("Rendering chart", 0.8)
        for i, v in enumerate(vals):
            bar = "▇" * int((v / maxv) * 35)
            print(f"  {C.C}[{i:>2}]{C.END} {C.B}{v:>8.2f}{C.END} {C.G}{bar}{C.END}")
    except ValueError:
        print(C.R + "  [-] Invalid input." + C.END)
    pause()

def py_ai():
    banner()
    spinner("Booting P.Y.AI neural core", 1.2)
    slow_print("  [7] P.Y.AI CHATBOT\n")
    print(C.Y + "  [i] Type 'quit' to exit chat." + C.END)
    knowledge = {
        "hello": "Hi! I am P.Y.AI. How can I help you?",
        "hi": "Hello! Ask me anything.",
        "who are you": "I am P.Y.AI, the mini AI inside OpenOsintPY.",
        "help": "Ask me about OSINT, tracing, or just say hi!",
        "osint": "OSINT = Open Source Intelligence - info gathering from public sources.",
    }
    while True:
        q = input(C.G + "  [You] > " + C.END).strip().lower()
        if q in ("quit", "exit", "q"):
            print(C.Y + "  [P.Y.AI] Bye! 👋" + C.END)
            break
        answer = knowledge.get(q) or next(
            (v for k, v in knowledge.items() if k in q),
            random.choice(["Interesting... tell me more.",
                           "I'm still learning. Ask me about OSINT!",
                           "Hmm, my neural core needs more training!"]))
        spinner("P.Y.AI thinking", 0.5)
        print(C.C + "  [P.Y.AI] " + answer + C.END)
    pause()

def spoof():
    banner()
    spinner("Initializing spoof engine", 0.6)
    slow_print("  [8] SPOOF TOOL\n")
    uas = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Firefox/121.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1.15",
        "Googlebot/2.1 (+http://www.google.com/bot.html)",
    ]
    ua = random.choice(uas)
    spinner("Generating fingerprint", 0.8)
    print(C.G + f"  [+] User-Agent: {ua}" + C.END)
    target = input(C.G + "  [?] URL to test (or Enter to skip): " + C.END).strip()
    if target and HAS_REQUESTS:
        spinner("Sending request", 1.0)
        try:
            r = requests.get(target, headers={"User-Agent": ua}, timeout=10)
            print(C.G + f"  [+] Status: {r.status_code}" + C.END)
            for k, v in r.headers.items():
                print(C.C + f"      {k}: {v}" + C.END)
        except Exception as e:
            print(C.R + f"  [-] Failed: {e}" + C.END)
    pause()

def wifi_lookup():
    banner()
    spinner("Initializing WiFi scanner", 0.6)
    slow_print("  [9] WIFI LOOKUP\n")
    if os.name == "nt":
        spinner("Reading interfaces", 0.8)
        os.system("netsh wlan show interfaces")
    else:
        spinner("Reading interfaces", 0.8)
        os.system("ip a 2>/dev/null || ifconfig")
    host = input(C.G + "  [?] Scan local IP for open ports (or Enter to skip): " + C.END).strip()
    if host:
        common = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 8080]
        print(C.C + f"  [*] Scanning {host} ..." + C.END)
        for port in common:
            sys.stdout.write(f"\r  {C.Y}Testing port {port:<5}{C.END}")
            sys.stdout.flush()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.4)
            if s.connect_ex((host, port)) == 0:
                print(C.G + f"  [+] OPEN : {port}" + C.END)
            s.close()
        print(" " * 30, end="\r")
        print(C.G + "  [+] Scan complete." + C.END)
    pause()

def create_website():
    banner()
    spinner("Initializing website builder", 0.6)
    slow_print("  [10] WEBSITE CREATOR\n")
    title = input(C.G + "  [?] Site title: " + C.END) or "My Site"
    text = input(C.G + "  [?] Main text: " + C.END) or "Welcome!"
    fname = input(C.G + "  [?] Filename (e.g. index.html): " + C.END) or "index.html"
    spinner("Building HTML", 1.0)
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
body {{ background:#0d1117; color:#00ff88; font-family:monospace; text-align:center; padding-top:15%; }}
h1 {{ color:#00ff88; text-shadow:0 0 10px #00ff88; }}
p {{ color:#58a6ff; }}
footer {{ position:fixed; bottom:10px; width:100%; color:#555; }}
</style>
</head>
<body>
<h1>{title}</h1>
<p>{text}</p>
<footer>Created by injectorX69</footer>
</body>
</html>"""
    with open(fname, "w", encoding="utf-8") as f:
        f.write(html)
    print(C.G + f"  [+] Saved: {os.path.abspath(fname)}" + C.END)
    webbrowser.open("file://" + os.path.abspath(fname))
    pause()

def fake_windows7():
    banner()
    spinner("Building Windows 7 decoy page", 0.8)
    slow_print("  [11] FAKE WINDOWS 7 PAGE (awareness demo)\n")
    fname = "windows7.html"
    html = """<!DOCTYPE html>
<html>
<head>
<title>Windows 7</title>
<style>
body{background:#1a4f8b;font-family:'Segoe UI',Arial;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.win{background:linear-gradient(#e8f0fe,#cfe0f5);border:1px solid #5a8ac6;border-radius:8px;padding:30px;width:320px;box-shadow:0 10px 40px rgba(0,0,0,.5);text-align:center}
.avatar{width:90px;height:90px;border-radius:50%;background:#7ab0e8;margin:0 auto 10px;border:3px solid #fff}
input{width:90%;padding:8px;margin:6px 0;border:1px solid #9bb;border-radius:4px}
button{background:linear-gradient(#5a9be0,#2d6fb5);color:#fff;border:1px solid #1d4e85;padding:8px 30px;border-radius:4px;cursor:pointer}
h2{color:#1d4e85;margin-bottom:15px}
</style>
</head>
<body>
<div class="win">
<div class="avatar"></div>
<h2>Windows 7</h2>
<input type="text" placeholder="Username">
<input type="password" placeholder="Password">
<br><button>Log on</button>
<p style="font-size:11px;color:#555">* SECURITY AWARENESS DEMO PAGE *</p>
</div>
</body>
</html>"""
    with open(fname, "w", encoding="utf-8") as f:
        f.write(html)
    print(C.G + f"  [+] Saved: {os.path.abspath(fname)}" + C.END)
    webbrowser.open("file://" + os.path.abspath(fname))
    pause()

def whatsapp_share():
    banner()
    spinner("Initializing WhatsApp link builder", 0.6)
    slow_print("  [12] WHATSAPP SHARE LINK\n")
    msg = input(C.G + "  [?] Message: " + C.END) or "Hello from OpenOsintPY!"
    url = "https://wa.me/?text=" + msg.replace(" ", "%20")
    print(C.G + f"  [+] Link: {url}" + C.END)
    if input(C.G + "  [?] Open? (y/n): " + C.END).lower() == "y":
        webbrowser.open(url)
    pause()

def update_tool():
    banner()
    spinner("Checking for updates", 1.2)
    slow_print("  [13] UPDATE\n")
    version = "2.0.0"
    print(C.G + f"  [+] Version: {version} (latest)" + C.END)
    for mod in [("requests", HAS_REQUESTS)]:
        print((C.G + "      [OK] " if mod[1] else C.R + "      [MISSING] ") + mod[0] + C.END)
    try:
        import phonenumbers
        print(C.G + "      [OK] phonenumbers" + C.END)
    except ImportError:
        print(C.R + "      [MISSING] phonenumbers  ->  pip install phonenumbers" + C.END)
    print(C.G + "  [+] All systems up to date." + C.END)
    pause()

# ------------------------- MENU -------------------------
MENU_ITEMS = [
    ("1",  "Name Tracer",            "G"),
    ("2",  "PhoneNum Tracer",        "G"),
    ("3",  "IP Lookup",              "G"),
    ("4",  "WhatsApp Tracer",        "G"),
    ("5",  "TikTok Lookup",          "G"),
    ("6",  "CMD Graph",              "G"),
    ("7",  "P.Y.AI  (chatbot)",      "M"),
    ("8",  "Spoof",                  "G"),
    ("9",  "WiFi Lookup",            "G"),
    ("10", "Create Website",         "G"),
    ("11", "Fake Windows 7 Page",    "G"),
    ("12", "WhatsApp Share Link",    "G"),
    ("13", "Update",                 "Y"),
    ("0",  "Exit",                   "R"),
]

def menu():
    print(C.C + C.BOLD + "  ╔" + "═" * 46 + "╗" + C.END)
    print(C.C + C.BOLD + "  ║" + " M A I N   M E N U ".center(46) + "║" + C.END)
    print(C.C + C.BOLD + "  ╠" + "═" * 46 + "╣" + C.END)
    for num, label, col in MENU_ITEMS:
        color = getattr(C, col)
        print(f"  ║ {color}{num:>2}{C.END} {C.W}|{C.END} {color}{label:<40}{C.END}║")
    print(C.C + C.BOLD + "  ╚" + "═" * 46 + "╝" + C.END)
    print(C.GR + "  " + "─" * 68 + C.END)
    print(C.M + "        ★ OpenOsintPY v2.0 ★  Created by injectorX69 ★" + C.END)

def main():
    if os.name == "nt":
        os.system("")  # enable ANSI colors on Windows
    boot_sequence()
    actions = {
        "1": name_tracer, "2": phone_tracer, "3": ip_lookup,
        "4": whatsapp_tracer, "5": tiktok_lookup, "6": cmd_graph,
        "7": py_ai, "8": spoof, "9": wifi_lookup,
        "10": create_website, "11": fake_windows7,
        "12": whatsapp_share, "13": update_tool,
    }
    while True:
        clear()
        # quick banner (no slow boot on every loop)
        print(C.R + C.BOLD + BANNER + C.END)
        menu()
        choice = input(C.B + C.BOLD + "  [>] Select option: " + C.END).strip()
        if choice == "0":
            spinner("Shutting down", 0.8)
            print(C.R + C.BOLD + "\n  [x] Goodbye!  — Created by injectorX69\n" + C.END)
            sys.exit(0)
        elif choice in actions:
            actions[choice]()
        else:
            print(C.R + "  [!] Invalid option!" + C.END)
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(C.R + "\n  [x] Interrupted. Goodbye!\n" + C.END)
        sys.exit(0)
